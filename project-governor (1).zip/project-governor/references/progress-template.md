# PROGRESS.md Template — Project Governor Reference

> **How to use this file (Governor only — never show or ship this file itself):**
> This is the exact structure of the PROGRESS.md output. Lines beginning with `[G:`
> are seeding instructions and must NEVER appear in the output. The embedded
> bracketed rules under each section heading (e.g. "[Rule: ...]") ARE part of the
> output — they make the file self-describing for every future Claude Code session.
> The finished file is named `PROGRESS.md` and lives in the project root. Target
> length: 40–60 lines.
>
> **ITERATION GUARD:** This template seeds a FRESH pre-build file only. If the
> build already exists (Iteration Mode in the skill), never generate from this
> template — preserve the live PROGRESS.md and append the revision items per the
> Iteration Mode rules in SKILL.md.

---

# PROGRESS — [Tool Name]

> Claude Code: read this file at the start of every session, before touching
> anything. Update it at every save point. Replace content — do not append.
> History lives in git.

**Session:** 0 — build not started
**Last updated:** [today's date] — by Project Governor, pre-build
**Live URL:** none yet [Rule: fill in after the first successful deploy]

## Current state
Nothing built. Repo contains CLAUDE.md, PROGRESS.md, product-spec.md[G: append if
applicable: ", supabase-setup.md", ", [brand file name] (brand skill — installed in
session 1)"].
[Rule: this section describes what exists and works right now — never what is
planned. Completed checklist items get absorbed here in compressed form.]

## Last session
None — the first build session has not happened yet.
[Rule: 3–5 lines maximum. Replace each session — what was built, changed, or fixed.]

## Remaining work
[G: seed in this exact order. One line per checkbox, plain language, reference spec
sections where helpful. Every view and every active arm from the spec appears
exactly once. Nothing from the spec's Out of Scope section appears at all.]
- [ ] First Session Setup: create docs/, move reference files[G: ", install the
      [skill-name] brand skill" if provided], commit (see CLAUDE.md Session Protocol)
[G: one checkbox per credential marked "needs creating", assigned to the builder:]
- [ ] Builder: create [Resend account / [provider] API key] and have it ready to
      enter as an environment variable
[G: if Supabase plan is Pro:]
- [ ] Builder: upgrade the Supabase project to Pro in the dashboard (manual billing
      step) before client use
[G: Tier 2/3, new project:]
- [ ] Create Supabase project "[confirmed-name]" via MCP — confirm the name with
      the builder first
- [ ] Build all tables and RLS policies[G: Tier 3: " and Auth configuration"], then
      write docs/supabase-setup.md
[G: Tier 2/3, existing project:]
- [ ] Connect to Supabase project "[name]" and read docs/supabase-setup.md before
      any database work
- [ ] [G: if this tool adds tables:] Create this tool's new tables and RLS
      policies, then update docs/supabase-setup.md
[G: one checkbox per view from the Screen and UI Structure section, in spec order:]
- [ ] Build [View name] — [one-line purpose from spec]
[G: one checkbox per remaining active arm, named by what it does:]
- [ ] Wire [arm]: [what it does, trigger in plain language]
[G: if GDPR applies:]
- [ ] Add the GDPR consent checkbox and confirmed data statement to the form
- [ ] Local test pass — full walkthrough of every view before deploying
[G: if the spec has an Acceptance Criteria section:]
- [ ] Acceptance criteria pass — verify every criterion in spec Section
      "Acceptance Criteria" before deploy
- [ ] Deploy to Netlify [G: MCP active: "via MCP, set environment variables" / not
      active: "— builder adds environment variables in the Netlify dashboard"]
[Rule: completed items leave this list and are absorbed into Current state. This
list only shrinks.]

## Build decisions
None yet.
[Rule: one line per decision made during the build that is not in the spec — prompt
structures, field formats, naming choices, library picks. Future sessions depend on
these to stay consistent.]

## Known issues
None.
[G: seed here anything carried over: open spec sections accepted at Gate 2,
provisional brand colors, refinable overflow items, flags from supabase-setup.md.]
[Rule: bugs, edge cases, and deferred fixes. One line each. Remove when resolved.]

## Notes for next session
None.
[Rule: the builder writes here between sessions. Claude Code reads these aloud at
session start, acts on them, then clears this section.]
