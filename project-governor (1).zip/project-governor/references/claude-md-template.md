# CLAUDE.md Template — Project Governor Reference

> **How to use this file (Governor only — never show or ship this file itself):**
> This is the exact structure of the CLAUDE.md output. Lines beginning with `[G:`
> are instructions to the Governor and must NEVER appear in the output. Blocks
> marked with a condition are included only when the condition applies — include
> them without the condition label. Replace every [bracketed placeholder] with real
> content derived from the documents. Omit sections that do not apply entirely;
> never output an empty section. The finished file is named `CLAUDE.md` and lives
> in the project root.

---

# [Tool Name]

## Identity
[One sentence: what it does, who uses it, how they access it.]
Tier: [N] — [plain English meaning, e.g. "public submission form, data persists to
Supabase, no login required"] ([D]+[A])
Spec version governed: v[X.X] — the version of docs/product-spec.md these rules
were derived from.
Position: [Standalone] OR [Tool [N] of [N] in the [project-name] stack — shares the
Supabase project with [other tool name(s)]; this tool [creates the schema / builds
on the existing schema]]

## Session Protocol
At the start of every session:
1. Pull the latest from main before reading anything else.
2. Check docs/product-spec.md: if its version is newer than the "Spec version
   governed" line in this file, STOP. Tell the builder: "The spec has changed since
   this CLAUDE.md was written — re-run the Project Governor on the revised spec
   before building, or these rules may contradict it." Do not build against a
   stale CLAUDE.md.
3. Read PROGRESS.md in the project root — it is the current state of this build.
   If it is missing, recreate it with the structure at the end of this section,
   then continue.
4. Increment the session number and update the date in PROGRESS.md.
5. If "Notes for next session" has content: repeat the notes back to the builder,
   treat them as this session's priorities, then clear the section.
6. If this is session 1, run First Session Setup below before any build work.

Save point — after completing any module, feature, fix, or schema change:
1. Update PROGRESS.md: current state, remaining work, build decisions, known issues.
[G: include line 2 only for Tier 2/3]
2. If the database was touched (any table, policy, bucket, or auth change), update
   docs/supabase-setup.md in the same save point.
3. Commit and push to main.
4. Tell the builder in one line: "Save point committed: [what changed]."
Do not start the next piece of work before the save point is pushed. Never end a
session without one — an ending session is a save point.

First Session Setup (session 1 only):
1. Create docs/ and move product-spec.md into it. [G: if existing Supabase project,
   add: "Move supabase-setup.md into docs/."]
[G: include step 2 only if a brand artifact was provided]
2. Install the brand skill: create .claude/skills/[skill-name]/ and place the
   provided brand file there as SKILL.md (add minimal name/description frontmatter
   if it has none).
3. Announce what moved, then commit and push before building anything.

PROGRESS.md structure (for the recreate rule): status header (Session / Last
updated / Live URL), Current state, Last session (3–5 lines, replace each session),
Remaining work (shrinking checklist), Build decisions (one line each), Known
issues, Notes for next session.

## Commands
[G: React + Vite variant]
```
npm install
npm run dev
npm run build
```
[G: HTML/CSS/JS variant]
```
npx serve .
```

## Tech Stack
[G: one line, composed:] [React · Vite · Tailwind CSS · shadcn/ui] OR [HTML · CSS ·
JavaScript] · Netlify [· Supabase — if Tier 2/3] [· Resend — if email arm] [· [AI
provider] API — if AI arm]
Deployment: GitHub → Netlify, auto-deploys from main. [G: if Netlify MCP active:]
Netlify MCP is active — create the site, set environment variables, and deploy via
MCP. [G: if not active:] Netlify MCP is not active — the builder connects the repo
and enters environment variables in the Netlify dashboard; remind them before the
first deploy.

## Arms
[G: one line per active arm; omit the whole section if no arms. Formats:]
AI API — [user-triggered — /netlify/functions/[name].js / database-triggered —
Supabase Edge Function] — [what it does] — max [N] tokens per request — input:
[typed answers / single document / large reports]
Email — [user-triggered — /netlify/functions/[name].js / database-triggered —
Supabase Edge Function] — fires on [trigger event] → [recipient] [— attaches
[file] in transit, never stored]
Export — browser only, no server function — [CSV / PDF: design per spec]
Scheduled — Netlify scheduled function — [cron or plain schedule] — [what it does]

## Environment Variables
[G: one line per variable. New project: names from the spec's API and Credentials
section plus the standard names below. Existing project: names exactly as listed in
supabase-setup.md. For React + Vite, browser-exposed Supabase variables carry the
VITE_ prefix (VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY); server-side keys never
do. Mark each key's storage location per its arm's function placement.]
[VITE_]SUPABASE_URL — Supabase: Project Settings → API → Project URL — Netlify env var
[VITE_]SUPABASE_ANON_KEY — Supabase: Project Settings → API → anon / public key — Netlify env var
[ANTHROPIC_API_KEY / OPENAI_API_KEY / GEMINI_API_KEY] — provider console — AI arm —
[Netlify env var — user-triggered / Supabase Edge Function secret — database-triggered]
[RESEND_API_KEY — Resend dashboard — email arm — [Netlify env var — user-triggered /
Supabase Edge Function secret — database-triggered]]

Key storage follows function placement: Netlify Functions and scheduled functions
read Netlify environment variables. Supabase Edge Functions read Supabase Edge
Function secrets — they CANNOT read Netlify environment variables. A key in the
wrong store fails silently at runtime. At session start, confirm these exist before
first use; prompt the builder for any that are missing. No value ever appears in
code or in any file committed to GitHub.
[G: omit this section for Tier 1 tools with no arms requiring credentials.]

## Supabase
[G: omit entirely for Tier 1. Choose ONE variant.]

[G: VARIANT — NEW PROJECT]
Project: "[confirmed-name]" — does not exist yet. At the start of session 1,
confirm this name with the builder, then create the project via Supabase MCP before
building anything. Region: [EU (Frankfurt) — if GDPR applies / nearest to users].
Plan: [Free — pauses after ~1 week without traffic / Pro — required for this tool;
the upgrade is a manual billing step in the Supabase dashboard, flag until done].

Build this schema — authoritative until docs/supabase-setup.md exists:
[table_name]: [field1], [field2], [field3 — FK to other_table], created_at
[table_name]: [field1], [field2], created_at
[G: if file storage:] Storage bucket: [bucket_name] — [public / private]

RLS — build these policies, never skip:
[table_name]: [one plain-English line, e.g. "anon: insert-only. No read access to
other rows."]
[G: Tier 3 only:]
Auth: [magic link / email and password] — [open signup / invite-only]
[G: A3 only:] Roles: [role1], [role2] — stored in user_roles as '[role1]', '[role2]'
[G: A3 + open signup:] New self-registered users have no role — the frontend must
show a pending state before granting access to any protected data.

After setup, write docs/supabase-setup.md and update it at every save point that
touches the database. It must contain: project name, project ID, project URL, plan,
every table with field names and types, RLS policies per table, auth configuration
[, storage buckets], notes for future sessions, and a last-updated line with date
and session number. From the moment it exists, that file is the schema source of
truth.

[G: VARIANT — EXISTING PROJECT]
Project: "[name]" — already exists. Project URL: [exact URL from supabase-setup.md]
docs/supabase-setup.md is the schema source of truth. Read it before any database
work. Never recreate tables or policies that already exist. Update it at every save
point that touches the database.
Plan: [Free / Pro — same flag rule as above if an upgrade is pending]

Tables this tool uses:
[table_name]: [field1], [field2], created_at
RLS: [one plain-English line per table]
[G: Tier 3 only — Auth/Roles lines as in the new-project variant]
[G: if this tool adds new tables to the existing project:] New tables to create for
this tool (then document in docs/supabase-setup.md): [list, same format as above]

## Hard Rules
[G: required in every CLAUDE.md. Never omit. Apply conditionals.]
- API keys never in any frontend file or GitHub commit. Storage follows function
  placement: Netlify env vars for Netlify Functions, Supabase Edge Function
  secrets for Supabase Edge Functions — Edge Functions cannot read Netlify env
  vars. Always called through a server-side function.
[G: if Supabase:] - Netlify Identity: never. Supabase Auth is the only
  authentication system in this stack.
[G: if Supabase:] - RLS: never disabled on any table. If a query fails, fix the
  policy or the query — never disable RLS to work around it.
[G: only if an actual server-side use case for the service role key was identified
in the spec or supabase-setup.md — never from the boilerplate credentials table
alone:] - Supabase service role key required for [stated use case]. Stored where
  its function runs (Netlify env var or Edge Function secret), as
  SUPABASE_SERVICE_ROLE_KEY — never in code. It bypasses all RLS. Flag to the
  builder before implementing.
[G: if AI arm AND (A1 OR open signup):] - Token limit: [N] tokens per request
  on the AI arm. This tool is accessible to unvetted users — no exceptions.
[G: if GDPR applies:] - GDPR: consent checkbox and the confirmed data statement
  required on the form before any data is submitted. Personal data collected:
  [fields]. Deletion requests go to [contact]. [G: new Supabase project only:]
  Supabase region: EU (Frankfurt). [G: existing project in a non-EU region: flag
  to the builder in PROGRESS.md Known Issues instead — region cannot change.]
[G: if stack on existing project:] - This tool shares a Supabase project with
  [other tool(s)]. Protected tables — [list tables NOT in this tool's spec] — must
  not be modified: no schema changes, no RLS changes. Query them only as documented
  in docs/supabase-setup.md.

## Project Structure
[G: derive from the spec or use this default. Omit if the spec leaves structure to
Claude Code's judgment — but keep the file-location lines in Reference Docs.]
```
/                     ← root: CLAUDE.md, PROGRESS.md only
/src
  /components
  /lib                ← Supabase client, utilities
/netlify/functions    ← user-triggered and scheduled arms
/docs                 ← product-spec.md[, supabase-setup.md]
/.claude/skills/[skill-name]/   ← brand skill[, if provided]
/public/assets
```

## Brand
[G: VARIANT — brand artifact provided]
Brand is governed by the [skill-name] skill at .claude/skills/[skill-name]/SKILL.md
(installed in First Session Setup). Invoke it for any UI or visual work.
Hard rules that hold even if the skill is not loaded:
- Background: [hex] — never white or Tailwind gray defaults
- Accent: [hex] — never Tailwind blue defaults
- Font: [family] for all text
- [border-radius / shadow / other explicit "never" rule]

[G: VARIANT — no artifact, inline block from Phase 3 Option A]
No brand skill yet. These inline rules apply until one is added to the repo (then
install it per First Session Setup and defer to it):
- Background: [hex] · Accent: [hex] · Font: [family]
- No drop shadows. Rounded corners: 4px maximum.

[G: VARIANT — no brand at all]
No brand defined. Use a clean neutral default: white background, slate text, one
restrained accent, Inter. If a brand skill is added to the repo later, install it
per First Session Setup and defer to it.

## Business Rules
[G: one line per rule, concrete and unambiguous. Omit section if none.]
[e.g. "Score: total weighted points divided by maximum possible, shown as a percentage."]
[e.g. "Status defaults to 'pending' on insert. Only the admin role can set 'approved'."]

Out of scope — do not build:
[G: one line per deferred item from the spec's Out of Scope section. Omit if none.]

## Reference Docs
Read before building the related part:
- docs/product-spec.md — full module specs, UI sections, logic, arm detail
[G: Tier 2/3:] - docs/supabase-setup.md — schema source of truth [(created in
  session 1) / (exists — read first)]
[G: if brand artifact:] - .claude/skills/[skill-name]/SKILL.md — full brand system
PROGRESS.md in the root is read at every session start per the Session Protocol.
